Sample application for test automation.

Site is deployed at https://automationbookstore.dev or can be downloaded and used locally.